package com.example.demo.Controllers;

import java.time.LocalTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.Repository.AvailabilityRepository;
import com.example.demo.Service.AvailabilityService;
import com.example.demo.Service.UserService;
import com.example.demo.model.Availability;
import com.example.demo.model.User;

import DTO.AvailabilityDTO;
import jakarta.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

@RestController
@RequestMapping("/availability")
public class AvailabilityController {

    @Autowired
    private AvailabilityService availabilityService;

    @PostMapping("/assign")
    public ResponseEntity<String> assignAvailability(
            @RequestParam String dayOfWeek,
            @RequestParam String startTime,
            @RequestParam String endTime,
            @RequestParam(required = false) String preferredSkillLevels,
            HttpSession session) {

        // Fetch the logged-in user from the session
        User loggedInUser = (User) session.getAttribute("loggedInUser");
        
        if (loggedInUser == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("User not logged in");
        }

        // Create a DTO for the new availability
        AvailabilityDTO availabilityDTO = new AvailabilityDTO();
        availabilityDTO.setDayOfWeek(dayOfWeek);
        availabilityDTO.setStartTime(LocalTime.parse(startTime));
        availabilityDTO.setEndTime(LocalTime.parse(endTime));
        availabilityDTO.setPreferredSkillLevels(preferredSkillLevels);

        // Save availability for the logged-in user
        availabilityService.saveAvailability(loggedInUser, availabilityDTO);

        return ResponseEntity.ok("Availability successfully assigned to user!");
    }

    @PostMapping("/update/{availabilityId}")
    public ResponseEntity<String> updateAvailability(
            @PathVariable Long availabilityId,
            @RequestParam String dayOfWeek,
            @RequestParam String startTime,
            @RequestParam String endTime,
            @RequestParam(required = false) String preferredSkillLevels,
            HttpSession session) {

        // Fetch the logged-in user from the session
        User loggedInUser = (User) session.getAttribute("loggedInUser");

        if (loggedInUser == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("User not logged in");
        }

        // Create a DTO for the updated availability
        AvailabilityDTO availabilityDTO = new AvailabilityDTO();
        availabilityDTO.setDayOfWeek(dayOfWeek);
        availabilityDTO.setStartTime(LocalTime.parse(startTime));
        availabilityDTO.setEndTime(LocalTime.parse(endTime));
        availabilityDTO.setPreferredSkillLevels(preferredSkillLevels);

        // Update availability for the logged-in user
        availabilityService.updateAvailability(availabilityId, availabilityDTO, loggedInUser);

        return ResponseEntity.ok("Availability successfully updated!");
    }
}
