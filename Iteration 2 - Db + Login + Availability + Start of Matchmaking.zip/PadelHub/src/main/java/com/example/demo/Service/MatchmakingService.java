package com.example.demo.Service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Repository.AvailabilityRepository;
import com.example.demo.Repository.MatchPlayerRepository;
import com.example.demo.Repository.MatchRepository;
import com.example.demo.model.Availability;
import com.example.demo.model.Match;
import com.example.demo.model.MatchPlayer;
import com.example.demo.model.User;

@Service
public class MatchmakingService {

    @Autowired
    private AvailabilityRepository availabilityRepository;

    @Autowired
    private MatchRepository matchRepository;

    @Autowired
    private MatchPlayerRepository matchPlayerRepository;

    // Create a match for the user based on their availability and preferences
    public Match createMatch(Long userId) {
        // Get the user's availability
        List<Availability> userAvailability = availabilityRepository.findByUserId(userId); // Updated to reflect foreign key change

        if (userAvailability.isEmpty()) {
            throw new RuntimeException("No availability found for user with ID: " + userId);
        }

        // Use the first availability entry as a sample to find compatible matches
        Availability sampleAvailability = userAvailability.get(0);
        List<String> daysOfWeek = userAvailability.stream()
                .map(Availability::getDayOfWeek)
                .distinct()
                .collect(Collectors.toList());

        LocalTime startTime = sampleAvailability.getStartTime();
        LocalTime endTime = sampleAvailability.getEndTime();
        String skillLevel = sampleAvailability.getPreferredSkillLevels();

        // Find compatible availabilities by checking the availability for each day and time
        List<Availability> compatibleAvailabilities = new ArrayList<>();
        
        // Iterate through the days of the week and find availabilities within the time range
        for (String day : daysOfWeek) {
            compatibleAvailabilities.addAll(
                availabilityRepository.findByDayOfWeekAndStartTimeBetween(day, startTime, endTime)
            );
        }

        // Filter compatible players by skill level
        compatibleAvailabilities = compatibleAvailabilities.stream()
                .filter(a -> a.getPreferredSkillLevels().equals(skillLevel))
                .collect(Collectors.toList());

        // Exclude the user's own availability from the list of compatible players
        compatibleAvailabilities.removeIf(a -> a.getUser().getId().equals(userId));

        // Check if there are enough compatible players for matchmaking
        if (compatibleAvailabilities.size() < 3) {
            throw new RuntimeException("Not enough compatible players found for matchmaking.");
        }

        // Randomly select 3 other players (you could apply more sophisticated logic here if desired)
        List<Availability> selectedAvailabilities = compatibleAvailabilities.stream()
                .limit(3) // Select the first 3 players
                .collect(Collectors.toList());

        // Create a new match
        Match match = new Match();
        match.setMatchDate(LocalDate.now());  // Set current date for simplicity
        match.setMatchTime(sampleAvailability.getStartTime()); // Use the user's start time
        matchRepository.save(match);

        // Add the user and selected players to the match
        addPlayerToMatch(match, userId); // Add the requesting user
        for (Availability availability : selectedAvailabilities) {
            addPlayerToMatch(match, availability.getUser().getId()); // Add selected players to the match
        }

        return match;
    }

    // Helper method to assign a player to a match
    private void addPlayerToMatch(Match match, Long userId) {
        MatchPlayer matchPlayer = new MatchPlayer();
        matchPlayer.setMatch(match);
        
        // Instead of directly setting user ID, ensure proper association with the User entity
        User user = new User();
        user.setId(userId); // Assuming user ID exists and user can be fetched by ID
        matchPlayer.setUser(user);  // Set the user object in the match player
        
        matchPlayerRepository.save(matchPlayer); // Save the player match relation
    }
}


