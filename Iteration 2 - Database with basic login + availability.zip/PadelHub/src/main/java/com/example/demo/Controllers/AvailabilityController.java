package com.example.demo.Controllers;

import java.time.LocalTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.Repository.AvailabilityRepository;
import com.example.demo.Service.AvailabilityService;
import com.example.demo.model.Availability;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

@RestController
@RequestMapping("/availability")
public class AvailabilityController {
    @Autowired
    private AvailabilityService availabilityService;

    @PostMapping("/assign")
    public ResponseEntity<String> assignAvailability(
            @RequestParam Long userId,
            @RequestParam String dayOfWeek,
            @RequestParam String startTime,
            @RequestParam String endTime,
            @RequestParam(required = false) String preferredSkillLevels) {
        // Create a new Availability instance
        Availability availability = new Availability();
        availability.setDayOfWeek(dayOfWeek);
        availability.setStartTime(LocalTime.parse(startTime));
        availability.setEndTime(LocalTime.parse(endTime));
        availability.setPreferredSkillLevels(preferredSkillLevels);

        // Assign availability to the user
        availabilityService.assignAvailabilityToUser(userId, availability);

        return ResponseEntity.ok("Availability successfully assigned to user!");
    }
}
