package DTO;

import java.time.LocalTime;

public class AvailabilityDTO {
    private String dayOfWeek;
    private LocalTime startTime; // Use String for easier parsing from JSON or form data
    private LocalTime endTime;
    private String preferredSkillLevels;

    // Getters and Setters
    public String getDayOfWeek() {
        return dayOfWeek;
    }

    public void setDayOfWeek(String dayOfWeek) {
        this.dayOfWeek = dayOfWeek;
    }

    public LocalTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalTime startTime) {
        this.startTime = startTime;
    }

    public LocalTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalTime endTime) {
        this.endTime = endTime;
    }

    public String getPreferredSkillLevels() {
        return preferredSkillLevels;
    }

    public void setPreferredSkillLevels(String preferredSkillLevels) {
        this.preferredSkillLevels = preferredSkillLevels;
    }
}
