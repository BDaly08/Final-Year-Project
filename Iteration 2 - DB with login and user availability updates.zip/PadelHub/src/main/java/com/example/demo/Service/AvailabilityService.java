package com.example.demo.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Repository.AvailabilityRepository;
import com.example.demo.Repository.UserRepository;
import com.example.demo.model.Availability;
import com.example.demo.model.User;

import DTO.AvailabilityDTO;

@Service
public class AvailabilityService {

    @Autowired
    private AvailabilityRepository availabilityRepository;

    @Autowired
    private UserRepository userRepository;

    // Save availability for the logged-in user
    public void saveAvailability(User user, AvailabilityDTO availabilityDTO) {
        Availability availability = new Availability();
        
        // Ensure the availability is linked to the logged-in user
        availability.setUser(user);  // Associate availability with the logged-in user
        
        // Set other properties from the DTO
        availability.setDayOfWeek(availabilityDTO.getDayOfWeek());
        availability.setStartTime(availabilityDTO.getStartTime());
        availability.setEndTime(availabilityDTO.getEndTime());
        availability.setPreferredSkillLevels(availabilityDTO.getPreferredSkillLevels());

        // Save availability
        availabilityRepository.save(availability);
    }

    // Method to update availability if needed
    public void updateAvailability(Long availabilityId, AvailabilityDTO availabilityDTO, User user) {
        Availability availability = availabilityRepository.findById(availabilityId)
                .orElseThrow(() -> new RuntimeException("Availability not found"));
        
        // Ensure the availability belongs to the logged-in user
        if (!availability.getUser().equals(user)) {
            throw new RuntimeException("You do not have permission to update this availability");
        }
        
        // Update the availability fields
        availability.setDayOfWeek(availabilityDTO.getDayOfWeek());
        availability.setStartTime(availabilityDTO.getStartTime());
        availability.setEndTime(availabilityDTO.getEndTime());
        availability.setPreferredSkillLevels(availabilityDTO.getPreferredSkillLevels());

        // Save updated availability
        availabilityRepository.save(availability);
    }
}



