package com.example.demo.Controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Service.MatchmakingService;
import com.example.demo.model.Match;
import com.example.demo.model.User;

import jakarta.servlet.http.HttpSession;

@RestController
@RequestMapping("/matchmaking")
public class MatchmakingController {

    @Autowired
    private MatchmakingService matchmakingService;

    @PostMapping("/request")
    public ResponseEntity<Match> requestMatchmaking(HttpSession session) {
        User loggedInUser = (User) session.getAttribute("loggedInUser");

        if (loggedInUser == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        // Call the service to create a match and return the Match object
        Match result = matchmakingService.createMatch(loggedInUser.getId());

        // Return the Match object in the response body
        return ResponseEntity.ok(result); // return ResponseEntity with Match object
    }
}

