package com.example.demo.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.model.User;
import com.example.demo.Repository.UserRepository;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;

    // Method to save the user and calculate the skill rating
    public User saveUser(User user) {
        user.setSkillRating(calculateSkillRating(user)); // Calculate skill rating based on answers
        return userRepository.save(user);  // Save the user to the database
    }
    
    

    private int calculateSkillRating(User user) {
        // Counters for intermediate and expert answers
        int beginnerCount = 0;
        int intermediateCount = 0;
        int expertCount = 0;

        // Example: How long the user has been playing Padel (question0)
        if ("A".equals(user.getQuestion0())) beginnerCount++;  // Beginner - Never played before
        else if ("B".equals(user.getQuestion0())) intermediateCount++; // Intermediate - 0-6 months
        else if ("C".equals(user.getQuestion0()) || "D".equals(user.getQuestion0())) expertCount++; // Expert - Over a year

        // Example: Rating forearm shot (question1)
        if ("A".equals(user.getQuestion1())) beginnerCount++;  // Beginner - rating 1
        else if ("B".equals(user.getQuestion1())) intermediateCount++; // Intermediate - rating 2
        else if ("C".equals(user.getQuestion1()) || "D".equals(user.getQuestion1())) expertCount++;  // Expert

        // Example: Rating backhand shot (question2)
        if ("A".equals(user.getQuestion2())) beginnerCount++;  // Beginner - rating 1
        else if ("B".equals(user.getQuestion2())) intermediateCount++; // Intermediate - rating 2
        else if ("C".equals(user.getQuestion2()) || "D".equals(user.getQuestion2())) expertCount++;  // Expert

        // Example: Rating smash shot (question3)
        if ("A".equals(user.getQuestion3())) beginnerCount++;  // Beginner - rating 1
        else if ("B".equals(user.getQuestion3())) intermediateCount++; // Intermediate - rating 2
        else if ("C".equals(user.getQuestion3()) || "D".equals(user.getQuestion3())) expertCount++;  // Expert

        // Skill rating logic based on total counts of beginner, intermediate, and expert answers
        if (expertCount >= 2) {
            return 650;  // Expert level (when two or more expert answers)
        } else if (intermediateCount >= 2) {
            return 450;  // Intermediate level (when two or more intermediate answers)
        } else {
            return 200;  // Beginner level (default for fewer intermediate or expert answers)
        }
    }

}

