package com.example.demo.Repository;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Availability;




@Repository
public interface AvailabilityRepository extends JpaRepository<Availability, Long> {

    // Find availabilities based on the day and time range (without skill level)
    List<Availability> findByDayOfWeekAndStartTimeBetween(
            String dayOfWeek, LocalTime startTime, LocalTime endTime);

    // Find availabilities by skill level
    List<Availability> findByPreferredSkillLevels(String preferredSkillLevels);

 // Find all availabilities for a specific user
    List<Availability> findByUserId(Long userId);
}



