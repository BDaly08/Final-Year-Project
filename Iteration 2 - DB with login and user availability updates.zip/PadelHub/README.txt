bootstrap.min.css, font-awesome.min.css, magnific-popup.css, owl.carouosel.min.css,
slicknav.min.css, style.css, style.css.map
FontAwesome.otf, fontawesome-webfont.eot, fontawesome-webfont.svg, fontawesome-webfont.ttf, fontawesome.woff, fontawesome.woff2
img folder
bootstrap.min.js, jquery.magnific-popup.min.js, jquery.marquee.min.js, jquery.slicknav.js, jquery-3.3.1.min.js, main.js, owl.carousel.min.js
blog.html, blog-details.html, club.html, contact.html, index.html, main.html, result.html, schedule.html
- all this code taken from free Bootstrap template taken from Themewagon; https://themewagon.com/themes/free-bootstrap-4-html5-sports-website-template-specer/


pom.xml code taken from ChatGPT
*Prompt - this is the code i have in my registration html, what is the easiest way to send these inputs to a mysql database?
Response: <dependencies>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-web</artifactId>
    </dependency>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-data-jpa</artifactId>
    </dependency>
    <dependency>
        <groupId>mysql</groupId>
        <artifactId>mysql-connector-java</artifactId>
    </dependency>
</dependencies>



ClubController and HomepageController - /*Code taken from ChatGPT 
 * Prompt: im getting this error; There was an unexpected error (type=Not Found, status=404).
No static resource club.html.

Code received: @Controller
public class ClubController {

    @GetMapping("/club")
    public String clubPage() {
        return "club"; // This maps to club.html in the templates directory
    }
}
 */
 
 
 
 Login.html and loginstyle.css code taken from geeksforgeeks.org - https://www.geeksforgeeks.org/html-login-form/
 registration.html and registration.css code taken from w3schools.com - https://www.w3schools.com/howto/howto_css_register_form.asp
 