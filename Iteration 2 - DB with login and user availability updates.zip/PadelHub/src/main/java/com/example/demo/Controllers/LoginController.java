package com.example.demo.Controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;

import com.example.demo.Repository.UserRepository;
import com.example.demo.Service.UserService;
import com.example.demo.model.User;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.util.HashMap;
import java.util.Map;

@RestController
public class LoginController {

    @Autowired
    private UserService userService;

    @PostMapping("/login")
    public ResponseEntity<String> login(
            @RequestParam("email") String email,
            @RequestParam("password") String password,
            HttpServletResponse response,
            HttpSession session) {

        boolean isAuthenticated = userService.authenticate(email, password);

        if (isAuthenticated) {
            // Retrieve user from the service
            User user = userService.findByEmail(email);

            // Store the entire user object in the session
            session.setAttribute("loggedInUser", user);  // Set entire user in session

            // Optionally, set a cookie with the user's name (for UI purposes)
            Cookie nameCookie = new Cookie("userName", user.getFirstName());
            nameCookie.setPath("/");
            nameCookie.setMaxAge(24 * 60 * 60);  // 1-day expiration
            nameCookie.setHttpOnly(true);  // Make the cookie accessible only to HTTP requests
            nameCookie.setSecure(true);  // Ensure the cookie is only sent over HTTPS
            response.addCookie(nameCookie);

            // Optionally, set a redirect location for the front-end
            response.setHeader("Location", "/index.html"); // Redirect to the homepage or dashboard
            return ResponseEntity.status(HttpStatus.FOUND).build();
        } else {
            // If authentication fails, return an error message
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials");
        }
    }

    }
