package com.example.demo.Controllers;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@RestController
public class LogoutController {

	@PostMapping("/logout")
    public ResponseEntity<String> logout(HttpSession session, HttpServletResponse response) {
        session.invalidate();  // Invalidate the session to log out
        Cookie nameCookie = new Cookie("userName", null);  // Clear the user name cookie
        nameCookie.setPath("/");
        nameCookie.setMaxAge(0);  // Expire the cookie immediately
        response.addCookie(nameCookie);

        return ResponseEntity.ok("Logged out successfully");
    }

}
