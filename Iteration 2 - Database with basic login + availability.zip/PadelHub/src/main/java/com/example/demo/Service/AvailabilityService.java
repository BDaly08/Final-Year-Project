package com.example.demo.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Repository.AvailabilityRepository;
import com.example.demo.Repository.UserRepository;
import com.example.demo.model.Availability;
import com.example.demo.model.User;

@Service
public class AvailabilityService {
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private AvailabilityRepository availabilityRepository;

    public void assignAvailabilityToUser(Long userId, Availability availability) {
        // Fetch the user by ID
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        // Associate the availability with the user
        availability.setUser(user);

        // Save the availability
        availabilityRepository.save(availability);
    }
}

