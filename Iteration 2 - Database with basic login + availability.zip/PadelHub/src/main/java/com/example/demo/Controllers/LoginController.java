package com.example.demo.Controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;

import com.example.demo.Repository.UserRepository;
import com.example.demo.Service.UserService;
import com.example.demo.model.User;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.util.HashMap;
import java.util.Map;

@RestController
public class LoginController {

    @Autowired
    private UserService userService;

    @PostMapping("/login")
    public ResponseEntity<Void> login(
            @RequestParam("email") String email,
            @RequestParam("password") String password,
            HttpServletResponse response) {

        boolean isAuthenticated = userService.authenticate(email, password);

        if (isAuthenticated) {
            // Retrieve user from the database
            User user = userService.findByEmail(email);

            // Set a cookie with the user's name
            Cookie nameCookie = new Cookie("userName", user.getFirstName());
            nameCookie.setPath("/"); // Make the cookie available across the app
            nameCookie.setMaxAge(24 * 60 * 60); // 1 day expiration
            response.addCookie(nameCookie);

            // Redirect to index.html
            response.setHeader("Location", "/index.html");
            return ResponseEntity.status(302).build();
        } else {
            // Redirect back to login page with error
            response.setHeader("Location", "/login.html?error=true");
            return ResponseEntity.status(302).build();
        }
    }
}

